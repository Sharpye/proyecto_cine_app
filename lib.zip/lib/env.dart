class Env{
  static const apiKey = 'e5b6c480631a1ccb8238b086c5d023cc';
  static const image = 'https://image.tmdb.org/t/p/w500';
}