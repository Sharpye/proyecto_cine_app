import 'package:flutter/material.dart';

class Colours {
  static const scaffoldBgColor = Color.fromARGB(255, 227, 216, 216);
  static const ratingColor = Color(0xFFFFC107);
}